<?php
require 'koneksi.php';

$kode = $nama = $brand = $warna = $tipe = $harga = '';
$pesan = '';


// =====================================================================
// TODO 1 - Cek apakah form sudah dikirim
//   ___1a___ = nilai atribut name pada <button> di form bawah
// =====================================================================
if (isset($_POST['___1a___'])) {

    // =================================================================
    // TODO 2 - Mengambil isi form
    //   Isi dengan nilai atribut name tiap <input> (= nama kolom tabel):
    //   ___2a___ kode   ___2b___ nama   ___2c___ brand
    //   ___2d___ warna  ___2e___ tipe   ___2f___ harga
    //   trim() = buang spasi di awal/akhir
    //   mysqli_real_escape_string() = amankan tanda kutip agar query tidak rusak
    // =================================================================
    $kode  = mysqli_real_escape_string($conn, trim($_POST['___2a___']));
    $nama  = mysqli_real_escape_string($conn, trim($_POST['___2b___']));
    $brand = mysqli_real_escape_string($conn, trim($_POST['___2c___']));
    $warna = mysqli_real_escape_string($conn, trim($_POST['___2d___']));
    $tipe  = mysqli_real_escape_string($conn, trim($_POST['___2e___']));
    $harga = trim($_POST['___2f___']);


    // =================================================================
    // TODO 3 - Validasi kolom kosong
    //   ___3a___ = string kosong. Ganti '___3a___' menjadi '' (dua kutip
    //   tanpa isi) di kelima tempat.
    // =================================================================
    if ($kode == '___3a___' || $nama == '___3a___' || $brand == '___3a___' ||
        $warna == '___3a___' || $tipe == '___3a___') {
        $pesan = 'Semua kolom wajib diisi.';

    // =================================================================
    // TODO 4 - Validasi harga
    //   ___4a___ = fungsi PHP untuk cek apakah nilai berupa angka (is_...)
    //   ___4b___ = batas bawah; harga harus lebih besar dari angka ini
    // =================================================================
    } elseif (!___4a___($harga) || $harga <= ___4b___ || $harga > 99999999999) {
        $pesan = 'Harga harus berupa angka positif, tanpa Rp dan titik.';
    } else {

        // =============================================================
        // TODO 5 - Cek kode mobil kembar
        //   ___5a___ = kolom yang menyimpan kode mobil
        //   ___5b___ = jika jumlah baris LEBIH DARI angka ini, kode sudah ada
        // =============================================================
        $cek = mysqli_query($conn,
            "SELECT id FROM showroom_mobil WHERE ___5a___ = '$kode'");
        if (mysqli_num_rows($cek) > ___5b___) {
            $pesan = 'Kode mobil sudah dipakai.';
        } else {

            // =========================================================
            // TODO 6 - Menyimpan data baru
            //   ___6a___ ___6b___ = dua kata perintah SQL tambah data
            //   ___6c___          = kata kunci sebelum daftar nilai
            //   Urutan nilai harus sama dengan urutan kolom.
            // =========================================================
            mysqli_query($conn,
                "___6a___ ___6b___ showroom_mobil
                 (kode_mobil, nama_mobil, brand_mobil, warna_mobil,
                  tipe_mobil, harga_mobil)
                 ___6c___ ('$kode', '$nama', '$brand', '$warna',
                         '$tipe', '$harga')");

            // =========================================================
            // TODO 7 - Kembali ke daftar mobil
            //   ___7a___ = halaman daftar + parameter pesan bernilai 1
            //              (format: namafile.php?parameter=nilai)
            // =========================================================
            header('Location: ___7a___');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah mobil - ShowRoom EAD</title>
    <link rel="stylesheet" href="style.css">
</head>
<body><main>
<p class="label">SHOWROOM EAD</p>
<h1>Tambah mobil</h1>
<p><a href="index.php">Kembali ke daftar</a></p>
<?php if ($pesan != ''): ?>
    <div class="kesalahan"><?= $pesan ?></div>
<?php endif; ?>

<!-- ===================================================================
     TODO 8 - Method form
       ___8a___ = get atau post? (data disimpan, jangan tampil di URL)
     =================================================================== -->
<form method="___8a___">

    <!-- ===============================================================
         TODO 9 - Atribut input
           name      = nama kolom tabel (sama dengan TODO 2)
           maxlength = panjang VARCHAR kolom itu di database.sql
           ___9a___ / ___9b___ = name / maxlength kode
           ___9c___ / ___9d___ = name / maxlength nama
           ___9e___ / ___9f___ = name / maxlength brand
           ___9g___ / ___9h___ = name / maxlength warna
           ___9i___ / ___9j___ = name / maxlength tipe
           ___9k___            = name harga
         =============================================================== -->
    <label for="kode">Kode mobil</label>
    <input id="kode" name="___9a___" maxlength="___9b___" value="<?= $kode ?>">
    <label for="nama">Nama mobil</label>
    <input id="nama" name="___9c___" maxlength="___9d___" value="<?= $nama ?>">
    <label for="brand">Brand</label>
    <input id="brand" name="___9e___" maxlength="___9f___"
           value="<?= $brand ?>">
    <label for="warna">Warna</label>
    <input id="warna" name="___9g___" maxlength="___9h___"
           value="<?= $warna ?>">
    <label for="tipe">Tipe (contoh: MPV, SUV, Sedan)</label>
    <input id="tipe" name="___9i___" maxlength="___9j___" value="<?= $tipe ?>">
    <label for="harga">Harga (angka saja, tanpa Rp dan titik)</label>
    <input id="harga" name="___9k___" value="<?= $harga ?>">

    <!-- ===============================================================
         TODO 10 - Tombol simpan
           ___10a___ = harus SAMA dengan ___1a___ di isset() atas
         =============================================================== -->
    <button name="___10a___">Simpan mobil</button>
</form>
</main></body>
</html>
